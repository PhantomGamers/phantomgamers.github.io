// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (C) 2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
 *
 * Compile: `gcc -o amd-rdrand-bug -O3 -mrdrnd -std=gnu99 amd-rdrand-bug.c`
 */

#include <stdio.h>
#include <stdint.h>
#include <immintrin.h>

int main(int argc, char *argv[])
{
	for (int j, i = 0; i < 2000; ++i) {
		for (j = 0; j < 100; ++j) {
			uint32_t val = 0;
			if (__builtin_ia32_rdrand32_step(&val)) {
				if (val != 0xffffffffU) {
					puts("Your RDRAND() does not have the AMD bug.");
					return 0;
				}
				break;
			}
		}
		if (j == 100) {
			puts("Failed to sample your RDRAND().");
			return 1;
		}
	}
	puts("Your RDRAND() returns -1 every time, which means it has the AMD bug.");
	return 1;
}
