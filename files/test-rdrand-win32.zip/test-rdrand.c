// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright (C) 2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
 *
 * Compile: `gcc -o test-rdrand -O3 -mrdrnd -std=gnu99 test-rdrand.c`
 */

#include <stdio.h>
#include <stdint.h>
#include <immintrin.h>

int main(int argc, char *argv[])
{
	for (int j, i = 0; i < 20; ++i) {
		for (j = 0; j < 10; ++j) {
			uint32_t val = 0;
			if (__builtin_ia32_rdrand32_step(&val)) {
				printf("RDRAND() = 0x%08x\n", val);
				break;
			}
		}
		if (j == 10) {
			puts("RDRAND() = FAIL");
			return 1;
		}
	}
	return 0;
}
